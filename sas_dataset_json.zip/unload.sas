filename P4621CD2 list;

%put NOTE: Unloading package sas_dataset_json, version 0.3.0, license MIT;
%put NOTE- *** START ***;

proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'SAS_DATASET_JSONIML'
   ,'SAS_DATASET_JSONCASLUDF'

   %put NOTE- Element of type macros generated from the file "m_json1_1_to_sas.sas" will be deleted;
   %put NOTE- ;
   ,"M_JSON1_1_TO_SAS                                                "

   %put NOTE- Element of type macros generated from the file "m_ndjson1_1_to_sas.sas" will be deleted;
   %put NOTE- ;
   ,"M_NDJSON1_1_TO_SAS                                              "

   %put NOTE- Element of type macros generated from the file "m_ndjson1_1_to_sas_stream.sas" will be deleted;
   %put NOTE- ;
   ,"M_NDJSON1_1_TO_SAS_STREAM                                       "

   %put NOTE- Element of type macros generated from the file "m_sas_to_json1_1.sas" will be deleted;
   %put NOTE- ;
   ,"M_SAS_TO_JSON1_1                                                "

   %put NOTE- Element of type macros generated from the file "m_sas_to_ndjson1_1.sas" will be deleted;
   %put NOTE- ;
   ,"M_SAS_TO_NDJSON1_1                                              "

  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"

  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'SAS_DATASET_JSONFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.sas_dataset_jsonfcmp.package;
run;

proc SQL noprint;
%put NOTE- Element of type data generated from the file "adsl.sas" will be deleted;
%put NOTE- ;
%sysfunc(ifc(%sysfunc(exist(adsl )),drop table adsl ,));

quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

%put NOTE- Element of type libname generated from the file "mylib1.sas" will be cleared;
%put NOTE- ;
libname mylib1  clear;

run;

data _null_ ;                                                                                        
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#sas_dataset_json(0.3.0)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#sas_dataset_json(0.3.0)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  

%put NOTE: Unloading package sas_dataset_json, version 0.3.0, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;

/* unload.sas end */
