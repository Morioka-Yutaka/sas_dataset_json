filename P4621CD2 list;

 %put NOTE- ;
 %put NOTE: Data for package sas_dataset_json, version 0.3.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-09-24T13:01:11; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(sas_dataset_json) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
if findw(lazyData, "adsl") then
do;
 put "NOTE- Dataset adsl from the file ""adsl.sas"" will be loaded";
 call execute('%nrstr(%include P4621CD2(_04_data.adsl.sas) / nosource2;)');
end;

run;
%put NOTE- ;
%put NOTE: Data for package sas_dataset_json, version 0.3.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

